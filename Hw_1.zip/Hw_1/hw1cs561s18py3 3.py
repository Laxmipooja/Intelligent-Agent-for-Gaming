import ast
import sys
import math
input_name= sys.argv[2]
Beta = float("inf")
Alpha1 = float("-inf")
f = open(input_name,"r") 
Outfile = open("output.txt","w")
VisitedList ={}
Alpha = {}
Adjacency_list = {}
Visited_Available ={}
R1_Available=""
R2_Available=""
R2_Available1=""
R1_Available1 = ""
finalMoves=[]
Cost = {"R1":0,"R2":0}
input = f.readlines()
Adjacency_matrix1=""
x1=""
input = [x.strip() for x in input]
RFL_1= input[2].replace("(","")
RFL_2= RFL_1.replace(")","")
RFL_3= RFL_2.split(",")
length1 = len(RFL_3)
d = dict(zip(RFL_3[::2],RFL_3[1::2]))
d = dict((k,int(v)) for k,v in d.items())
Eval = input[0].strip()
for x in input:
    if x.startswith("["):
       Adjacency_matrix1 = Adjacency_matrix1 + x + ","
Used_Vertices = input[len(input)-2]
length = len(Used_Vertices)
i1=0
while i1 < length1:
    a = RFL_3[i1]
    if (Visited_Available.get(a, "Never") == "Never")  and (Adjacency_list.get(a,"Never")=="Never"):
      Visited_Available[a]=1
      VisitedList[a]=1
    i1=i1+2
i1=0
keey = 0
while i1 < length1:
    a = RFL_3[i1]
    if Alpha.get(a, "Never") == "Never":
      Alpha[a]=keey
      Adjacency_list[keey] = a
    keey = keey+1
    i1=i1+2 
Depth = input[len(input)-1]
def Evaluate_RPL(d):
    Stale_Values=0
    length = len(d)
    a=0
    b=""
    c=0
    Total=0
    while c< length:
        b= Adjacency_list[c]
        Stale_Values = d[b]
        Total = Total+ Stale_Values
        c=c+1
    while a<length:
      b = Adjacency_list[a]
      Stale_Values=d[b]
      current_value = (((1/length)*Total) + Stale_Values)/2
      d[b] = current_value    
      a=a+1
    return d
if input[0].strip() != "Today":
   depth = 1 
   d=Evaluate_RPL(d)
def Adjacency_List(node,Adjacency_matrix):
  numcol=len(Adjacency_matrix[0])
  
  j=0
  i=int(Alpha[node])
  a=""
  while j < numcol:  
    if i!=j:
     if Adjacency_matrix[i][j]==1:
        a = a+Adjacency_list[j]+","    
    j=j+1
  if len(a) == 0:
     a =""
  else:   
    a=a.strip(',')
    a= a.split(",") 
  return a

def Marked(Adjacency_Matrix,Used_Vertices,Previous_Move,Next_Move,key_max):
    costR1=0
    costR2=0
    length = len(Used_Vertices)
    if length>1:
      Used_Vertices=Used_Vertices.split(",")
      length = len(Used_Vertices)
    Used_Vertices = list(Used_Vertices)
    i=0
    if Used_Vertices[0] != "*" and length ==1:
        if Previous_Move == "R1":
           Visited_Available[Used_Vertices[0]]="R1"
           costR1 = costR1 + d[Used_Vertices[0]]
           Cost["R1"]=costR1
           return Visited_Available
        else:
           Visited_Available[Used_Vertices[0]]="R2"
           costR2 = costR2 + d[Used_Vertices[0]]
           Cost["R2"]=costR2
           return Visited_Available
    elif length>1:
        while i<len(Used_Vertices):
            if Next_Move == "R1":
                if length%2 == 0:
                    Visited_Available[Used_Vertices[i]]="R1"
                    To_Added = Visited_Available[Used_Vertices[i]]
                    costR1 = costR1 + d[Used_Vertices[i]]
                    Cost["R1"]=costR1
                else:
                   Visited_Available[Used_Vertices[i]]="R2"
                   To_Added = Visited_Available[Used_Vertices[i]]
                   costR2 = costR2 + d[Used_Vertices[i]]
                   Cost["R2"]=costR2
            else:
                if length%2 == 0:
                    Visited_Available[Used_Vertices[i]]="R2"
                    To_Added = Visited_Available[Used_Vertices[i]]
                    costR2 = costR2 + d[Used_Vertices[i]]
                    Cost["R2"]=costR2
                else:
                   Visited_Available[Used_Vertices[i]]="R1"
                   To_Added = Visited_Available[Used_Vertices[i]]
                   costR1 = costR1 + d[Used_Vertices[i]]
                   Cost["R1"]=costR1
            i = i + 1
            length=length-1
        return Visited_Available    
    else:    
        return 0
Adjacency_matrix=ast.literal_eval(Adjacency_matrix1)
Rows = len(Adjacency_matrix)
Col =  len(Adjacency_matrix[0])
key_max1 = ""
for i in range(Rows):
    for j in range(Col):
        if Adjacency_matrix[i][j] == 0:
            key_max = max(d.keys(), key=(lambda k: d[k]))
        else:
            key_max = key_max1
            break
Used = input[len(input)-2]

if Used.find(",")!=-1:
      Used=Used.split(",")
      length = len(Used)
else:
    length=1
if input[1]== "R1" :
    if length%2 == 0:
        Next_Move = "R2"
        Previous_Move = "R1"
    else:
        Next_Move = "R1"
        Previous_Move = "R2"
elif input[1] == "R2":
    if length%2 == 0:
        Next_Move = "R1"
        Previous_Move = "R2"
    else:
        Next_Move = "R2"
        Previous_Move ="R1"  
Visited_Regions = Marked(Adjacency_matrix,Used_Vertices,Previous_Move,Next_Move,key_max)
if Visited_Regions!=0:
  Used = input[len(input)-2]
  if Used.find(",")!=-1:
      Used=Used.split(",")
      length = len(Used)
  else:
    length=1   
  if length>1:
      while length:
         if Previous_Move == "R1":
             if Next_Move == "R2":  
               for k1,v in Visited_Regions.items():
                 if v == 'R1':
                     R1=k1
                     R1_Available=Adjacency_List(R1,Adjacency_matrix)
               for k1,v in Visited_Regions.items():
                 if v == 'R2':
                     R2=k1
                     R2_Available=Adjacency_List(R2,Adjacency_matrix)
         if Previous_Move == "R2" :
             if Next_Move == "R1": 
               for k1,v in Visited_Regions.items():
                 if v == 'R1':
                     R1=k1
                     R1_Available=Adjacency_List(R1,Adjacency_matrix)
               for k1,v in Visited_Regions.items():
                 if v == 'R2':
                     R2=k1
                     R2_Available=Adjacency_List(R2,Adjacency_matrix)
         length = length-1
  elif length == 1:
      k=0
      if Previous_Move == "R1":
         for k1,v in Visited_Regions.items():
             if v == 'R1':
                R1=k1
         R1_Available = Adjacency_List(R1,Adjacency_matrix)
         while k<length1:
           if R1 != RFL_3[k]:
              R2_Available1 = RFL_3[k]+","+R2_Available1
           k=k+2
         R2_Available1 =  R2_Available1.strip(",")
         R2_Available=R2_Available1.split(",")
             
      else:
        if Previous_Move == "R2":
         for k2,v in Visited_Regions.items():
             if v == 'R2':
               R2=k2
         R2_Available = Adjacency_List(R2,Adjacency_matrix)
        while k<length1:
          if R2 != RFL_3[k]:
              R1_Available1 = RFL_3[k]+","+R1_Available1
          k=k+2
        R1_Available1 =  R1_Available1.strip(",")
        R1_Available=R1_Available1.split(",")
else:
     k=0
     if input[1]== "R1":
         while k<length1:
            R1_Available1 = RFL_3[k]+","+R1_Available1
            k=k+2
     else:
        while k<length1:
              R2_Available1 = RFL_3[k]+","+R2_Available1
              k=k+2
     R1_Available1 =  R1_Available1.strip(",")
     R1_Available=R1_Available1.split(",")  
     R2_Available1 =  R2_Available1.strip(",")
     R2_Available=R2_Available1.split(",")

R1_Available = sorted(R1_Available)
R2_Available = sorted(R2_Available)
R1_Available = list(R1_Available)
R2_Available = list(R2_Available)
Maximizer = input[1]


def FindBestMove(R1_Available,R2_Available,Next_Move,Previous_Move,d,Cost,VisitedList,Used_Vertices,Eval,Alpha1,Beta):
   VisitedListcopy12 = dict(VisitedList) 
   iterate = 0
   iterate1 = 0
   iterate = 0
   BestValue = float("-inf")   
   BestMove = ""
   Cost1 = dict(Cost)
   R1_AvailableCopy = list(R1_Available)
   R2_AvailableCopy= list(R2_Available)
   p=0
   if Used_Vertices.find(",")!=-1:  
      q=0
      Used_Vertices = Used_Vertices.split(",")
      length_Used_Vertices = len(Used_Vertices)
      while q < length_Used_Vertices:
         VisitedList[Used_Vertices[q]]= 0
         q=q+1
      VistedList_Multi = dict(VisitedList)
      if  len(R1_Available) >0:   
        while iterate < len(R1_Available) :
               a= R1_Available[iterate]
               if VisitedList[a] == 0:
                   index1 = R1_Available.index(a)
                   R1_Available.pop(index1)
               else:
                   iterate = iterate+1
      if  len(R2_Available) >0:
        while iterate1 < len(R2_Available) :
               a= R2_Available[iterate1]
               if VisitedList[a] == 0:
                   index1 = R2_Available.index(a)
                   R2_Available.pop(index1)
               else:
                   iterate1 = iterate1+1 
   else:
      VisitedList[Used_Vertices] = 0
   depth= len(Used_Vertices)
   lenR1 = len(R1_Available)
   lenR2 = len(R2_Available)
   if Next_Move == "R1" :
      if len(R1_Available)>0 and Visited_Regions!=0:            
        while p <lenR1:   
           Maximizer = "R1"
           iterate = 0
           Next_Turn = False
           picked = R1_Available[p]
           VisitedList[R1_Available[p]]=0  #R1 played
           costR1 = Cost["R1"] + d[R1_Available[p]]
           Cost["R1"]=costR1
           R1_Available = Adjacency_List(R1_Available[p],Adjacency_matrix)
           R1_Available = list(R1_Available)
           Cost["R1"] = costR1
           while iterate < len(R1_Available) :
               a= R1_Available[iterate]
               if VisitedList[a] == 0:
                   index1 = R1_Available.index(a)
                   R1_Available.pop(index1)
               else:
                   iterate = iterate+1
           iterate = 0
           while iterate < len(R2_Available) :
               a= R2_Available[iterate]
               if VisitedList[a] == 0:
                   index1 = R2_Available.index(a)
                   R2_Available.pop(index1)
               else:
                   iterate = iterate+1 
           choosedPath_value = minimax(R1_Available,R2_Available,depth,Next_Turn,Previous_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta)    
           Alpha1 = max(Alpha1,choosedPath_value)
           if Beta <= Alpha1:
                  break 
           if Eval != "Today":
                if choosedPath_value > BestValue:
                    BestValue = choosedPath_value
                    BestMove = picked
                finalMoves.append(round(choosedPath_value))  
           if choosedPath_value > BestValue and Eval == "Today":
               BestValue = choosedPath_value
               BestMove = picked 
           p=p+1
           R2_Available = list(R2_AvailableCopy)
           R1_Available = list(R1_AvailableCopy)
           Cost = dict(Cost1)
           VisitedList = dict(VisitedListcopy12)
           if input[len(input)-2].find(",")!=-1:
                VisitedList = dict(VistedList_Multi)
           else: 
               VisitedList[Used_Vertices] = 0
        return BestMove
      elif Next_Move == "R1" and Visited_Regions == 0:  
        Next_Move = "R2"
        Maximizer = input[1]
        while p < lenR1:
            R1AvailableCopy = list(R1_Available)
            iterate =0
            Next_Turn = False
            picked = R1_Available[p]
            VisitedList[R1_Available[p]] = 0  #R1 played in case of "*"
            costR1 = Cost["R1"] + d[R1_Available[p]]
            R1_Available = Adjacency_List(R1_Available[p],Adjacency_matrix)
            R1_Available = list(R1_Available)
            Cost["R1"]=costR1
            while iterate < len(R1_Available) :
                a= R1_Available[iterate]
                if VisitedList[a] == 0:
                    index1 = R1_Available.index(a)
                    R1_Available.pop(index1)
                else:
                    iterate = iterate+1
            iterate = 0
            while iterate < len(R1AvailableCopy):
                a= R1AvailableCopy[iterate]
                if VisitedList[a] == 0:
                    index1 = R1AvailableCopy.index(a)
                    R1AvailableCopy.pop(index1)
                    R2_Available = list(R1AvailableCopy)
                else:
                    iterate = iterate+1 
            choosedPath_value = minimax(R1_Available,R2_Available,depth,Next_Turn,Previous_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta)
            Alpha1 = max(Alpha1,choosedPath_value)
            if Beta <= Alpha1:
                  break 
            
            if Eval != "Today": 
                if choosedPath_value > BestValue:
                    BestValue = choosedPath_value
                    BestMove = picked
                finalMoves.append(math.ceil(choosedPath_value))
            if choosedPath_value > BestValue and Eval == "Today":
                BestValue = choosedPath_value  
                BestMove = picked    
            p=p+1
            R2_Available = list(R2_AvailableCopy)
            R1_Available = list(R1_AvailableCopy)
            Cost = dict(Cost1)
            VisitedList =dict(VisitedListcopy12)
        return BestMove      
   if Next_Move == "R2"  :
    p=0   
    if len(R2_Available)>0 and Visited_Regions!=0:
        Maximizer = "R2"
        while p < lenR2:
           iterate =0
           Next_Turn = False
           picked = R2_Available[p]
           VisitedList[R2_Available[p]] = 0  #R2 played
           costR2 = Cost["R2"] + d[R2_Available[p]]
           R2_Available = Adjacency_List(R2_Available[p],Adjacency_matrix)
           R2_Available = list(R2_Available)
           Cost["R2"]=costR2
           while iterate < len(R1_Available) :
               a= R1_Available[iterate]
               if VisitedList[a] == 0:
                   index1 = R1_Available.index(a)
                   R1_Available.pop(index1)
               else:
                   iterate = iterate+1
           iterate = 0
           while iterate < len(R2_Available):
               a= R2_Available[iterate]
               if VisitedList[a] == 0:
                   index1 = R2_Available.index(a)
                   R2_Available.pop(index1)
               else:
                       iterate = iterate+1 
           choosedPath_value = minimax(R1_Available,R2_Available,depth,Next_Turn,Previous_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta)
           Alpha1 = max(Alpha1,choosedPath_value)
           if Beta <= Alpha1:
             break
           if Eval != "Today":        #------->Main code for the execution
              if choosedPath_value > BestValue:
                 BestValue = choosedPath_value
                 BestMove = picked
              finalMoves.append(math.ceil(choosedPath_value))
           if choosedPath_value > BestValue and Eval == "Today":
               BestValue = choosedPath_value
               BestMove = picked 
           p=p+1
           R2_Available = list(R2_AvailableCopy)
           R1_Available = list(R1_AvailableCopy)
           Cost = dict(Cost1)
           VisitedList = dict(VisitedListcopy12)
           if input[len(input)-2].find(",")!=-1:
               VisitedList = dict(VistedList_Multi)
           else:
               VisitedList[Used_Vertices] = 0
        return BestMove
    elif Next_Move == "R2" and Visited_Regions == 0:
          Maximizer = input[1]
          Next_Move = "R1"
          while p < lenR2:
              R2AvailableCopy = list(R2_Available)
              iterate =0
              Next_Turn = False
              picked = R2_Available[p]
              VisitedList[R2_Available[p]] = 0  #R2 played in case of "*"
              costR2 = Cost["R2"] + d[R2_Available[p]]
              R2_Available = Adjacency_List(R2_Available[p],Adjacency_matrix)
              R2_Available = list(R2_Available)
              Cost["R2"]=costR2
              while iterate < len(R2_Available) :
                  a= R2_Available[iterate]
                  if VisitedList[a] == 0:
                      index1 = R2_Available.index(a)
                      R2_Available.pop(index1)
                  else:   
                      iterate = iterate+1
              iterate = 0
              while iterate < len(R2AvailableCopy):
                   a= R2AvailableCopy[iterate]
                   if VisitedList[a] == 0:
                       index1 = R2AvailableCopy.index(a)
                       R2AvailableCopy.pop(index1)
                       R1_Available = list(R2AvailableCopy)
                   else:
                       iterate = iterate+1 
              choosedPath_value = minimax(R1_Available,R2_Available,depth,Next_Turn,Previous_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta)
              Alpha1 = max(Alpha1,choosedPath_value)
              if Beta <= Alpha1:
                  break 
              if Eval != "Today":  
                  if choosedPath_value > BestValue:
                      BestValue = choosedPath_value
                      BestMove = picked  
                  finalMoves.append(math.ceil(choosedPath_value)) 
              if choosedPath_value > BestValue and Eval == "Today":
                  BestValue = choosedPath_value
                  BestMove = picked
              p=p+1
              R2_Available = list(R2_AvailableCopy)
              R1_Available = list(R1_AvailableCopy)
              Cost = dict(Cost1)
              VisitedList = dict(VisitedListcopy12)
          return BestMove 


def minimax(R1_Available,R2_Available,depth,Next_Turn,Current_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta):
    
    R1_AvailableCopy1 = list(R1_Available)
    R2_AvailableCopy1 = list(R2_Available)
    if Eval == "Today":
      if depth == int(Depth)+1 or (len(R1_Available)==0 and len(R2_Available)==0): 
         finalMoves.append(Cost[Maximizer])
         return Cost[Maximizer]
    else:
        if depth == int(Depth)+1 or (len(R1_Available)==0 and len(R2_Available)==0):
          return Cost[Maximizer]
    depth = depth+1
    p=0
    costR1 =0 
    costR2 =0
    lenR1 = len(R1_Available)
    lenR2 = len(R2_Available)
    if Next_Turn:
        if Current_Move == "R1":
           Next_Turn = False
           Next_Move = "R2"
           Best = float("-inf")
           if len(R1_Available)>0:
             while p < lenR1:
                  iterate =0
                  VisitedList1 = dict(VisitedList)
                  VisitedList[R1_Available[p]]=0  #R1 played
                  CostR2 = dict(Cost)
                  costR1 = Cost["R1"] + d[R1_Available[p]]
                  Cost["R1"]=costR1  
                  R1_Available = Adjacency_List(R1_Available[p],Adjacency_matrix)
                  R1_Available = list(R1_Available)
                  while iterate < len(R1_Available) :
                      a= R1_Available[iterate]
                      if VisitedList[a] == 0:
                          index1 = R1_Available.index(a)
                          R1_Available.pop(index1)
                      else:
                          iterate = iterate+1
                  iterate = 0
                  while iterate < len(R2_Available) :
                      a= R2_Available[iterate]
                      if VisitedList[a] == 0:
                          index1 = R2_Available.index(a)
                          R2_Available.pop(index1)
                      else:
                          iterate = iterate+1
                  Best = max(Best,minimax(R1_Available,R2_Available,depth,Next_Turn,Next_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta))
                  Alpha1 = max(Alpha1,Best)
                  if Beta <= Alpha1:
                      break
                  VisitedList=dict(VisitedList1)
                  R2_Available = list(R2_AvailableCopy1)
                  R1_Available = list(R1_AvailableCopy1)
                  Cost = dict(CostR2)
                  p=p+1
             return Best
           else:
             p=0
             while p < len(R2_Available):
                 iterate =0
                 VisitedList[R2_Available[p]]=0 
                 costR2 = Cost["R2"] + d[R2_Available[p]]
                 Cost["R2"]=costR2
                 while iterate < len(R2_Available) :
                      a= R2_Available[iterate]
                      if VisitedList[a] == 0:
                          index1 = R2_Available.index(a)
                          R2_Available.pop(index1)
                      else:
                          iterate = iterate+1
                 Best = max(Best,minimax(R1_Available,R2_Available,depth,Next_Turn,Next_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta))
             return Cost[Maximizer]
        else:
           Next_Turn = False
           Best = float("-inf")
           Next_Move = "R1"
           if len(R2_Available)>0:
             while p < lenR2:
                  iterate =0
                  VisitedList2=dict(VisitedList)
                  CostR3 = dict(Cost)
                  VisitedList[R2_Available[p]]=0  #R1 played
                  costR2 = Cost["R2"] + d[R2_Available[p]]
                  Cost["R2"]=costR2
                  R2_Available = Adjacency_List(R2_Available[p],Adjacency_matrix)
                  R2_Available = list(R2_Available)
                  while iterate < len(R1_Available) :
                      a= R1_Available[iterate]
                      if VisitedList[a] == 0:
                          index1 = R1_Available.index(a)
                          R1_Available.pop(index1)
                      else:
                          iterate = iterate+1
                  iterate = 0
                  while iterate < len(R2_Available) :
                      a= R2_Available[iterate]
                      if VisitedList[a] == 0:
                          index1 = R2_Available.index(a)
                          R2_Available.pop(index1)
                      else:
                          iterate = iterate+1
                  Best = max(Best,minimax(R1_Available,R2_Available,depth,Next_Turn,Next_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta))
                
                  Alpha1 = max(Alpha1,Best)
                  if Beta <= Alpha1:
                      break
                  VisitedList=dict(VisitedList2)
                  R2_Available = list(R2_AvailableCopy1)
                  R1_Available = list(R1_AvailableCopy1)
                  Cost=dict(CostR3)
                  p=p+1
             return Best
           else:
               p=0
               if depth != int(Depth):
                while p < len(R1_Available):
                  iterate =0
                  VisitedList[R1_Available[p]]=0 
                  costR1 = Cost["R1"] + d[R1_Available[p]]
                  Cost["R1"]=costR1
                  while iterate < len(R1_Available) :
                      a= R1_Available[iterate]
                      if VisitedList[a] == 0:
                          index1 = R1_Available.index(a)
                          R1_Available.pop(index1)
                      else:
                          iterate = iterate+1
                  Best = max(Best,minimax(R1_Available,R2_Available,depth,Next_Turn,Next_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta))
                return Cost[Maximizer]
    else:
     if Current_Move=="R1":
        Next_Turn = True
        Next_Move = "R2"
        Best = float("inf")
        if len(R1_Available)>0: 
          while p < lenR1:
                  iterate = 0
                  CostR4 = dict(Cost)
                  VisitedList3=dict(VisitedList)
                  VisitedList[R1_Available[p]] = 0  #R1 played
                  costR1 = Cost["R1"] + d[R1_Available[p]]
                  Cost["R1"]=costR1
                  R1_Available = Adjacency_List(R1_Available[p],Adjacency_matrix)
                  R1_Available = list(R1_Available)
                  while iterate < len(R1_Available) :
                      a= R1_Available[iterate]
                      if VisitedList[a] == 0:
                          index1 = R1_Available.index(a)
                          R1_Available.pop(index1)
                      else:
                          iterate = iterate+1
                  iterate = 0
                  while iterate < len(R2_Available) :
                      a= R2_Available[iterate]
                      if VisitedList[a] == 0:
                          index1 = R2_Available.index(a)
                          R2_Available.pop(index1)
                      else:
                          iterate = iterate+1 
                  Best = min(Best,minimax(R1_Available,R2_Available,depth,Next_Turn,Next_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta)) 
                  Beta = min(Beta,Best)
                  if Beta<=Alpha1:
                      break
                  VisitedList=dict(VisitedList3)
                  R2_Available = list(R2_AvailableCopy1)
                  R1_Available = list(R1_AvailableCopy1)
                  Cost = dict(CostR4)
                  p=p+1
          return Best
        else:   
         if depth != int(Depth):
          while p < len(R2_Available):
                 iterate =0
                 VisitedList[R2_Available[p]]=0 
                 costR2 = Cost["R2"] + d[R2_Available[p]]
                 Cost["R2"]=costR2
                 while iterate < len(R2_Available) :
                      a= R2_Available[iterate]
                      if VisitedList[a] == 0:
                          index1 = R2_Available.index(a)
                          R2_Available.pop(index1)
                      else:
                          iterate = iterate+1
                 Best = max(Best,minimax(R1_Available,R2_Available,depth,Next_Turn,Next_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha,Beta))
          return Cost[Maximizer] 
     elif Current_Move == "R2":
        Next_Turn = True
        Next_Move = "R1"
        Best = float("inf")
        if len(R2_Available)>0:
          while p < lenR2:
                  iterate = 0
                  VisitedList4=dict(VisitedList) 
                  VisitedList[R2_Available[p]] = 0  #R1 played
                  CostR5 = dict(Cost)
                  costR2 = Cost["R2"] + d[R2_Available[p]]
                  Cost["R2"]=costR2
                  picked = R2_Available[p]
                  R2_Available = Adjacency_List(R2_Available[p],Adjacency_matrix)
                  R2_Available = list(R2_Available)
                  while iterate < len(R1_Available) :
                       a= R1_Available[iterate]  
                       if VisitedList[a] == 0:
                           index1 = R1_Available.index(a)
                           R1_Available.pop(index1)
                       else:
                               iterate = iterate+1
                  iterate =0
                  while iterate < len(R2_Available) :
                       a= R2_Available[iterate]
                       if VisitedList[a] == 0:
                           index1 = R2_Available.index(a)
                           R2_Available.pop(index1)
                       else:
                           iterate = iterate+1 # I am here
                  Best = min(Best,minimax(R1_Available,R2_Available,depth,Next_Turn,Next_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta)) 
                  Beta = min(Beta,Best)
                  if Beta<=Alpha1:
                      break
                  VisitedList=dict(VisitedList4)
                  R2_Available = list(R2_AvailableCopy1)
                  R1_Available = list(R1_AvailableCopy1)
                  Cost=dict(CostR5)
                  p=p+1
          return Best
        else: 
          if depth != int(Depth):
           while p < len(R1_Available):
                 iterate =0
                 VisitedList[R1_Available[p]]=0 
                 costR1 = Cost["R1"] + d[R1_Available[p]]
                 Cost["R1"]=costR1
                 while iterate < len(R1_Available) :
                      a= R1_Available[iterate]
                      if VisitedList[a] == 0:
                          index1 = R1_Available.index(a)
                          R1_Available.pop(index1)
                      else:
                          iterate = iterate+1
                 Best = max(Best,minimax(R1_Available,R2_Available,depth,Next_Turn,Next_Move,VisitedList,d,Maximizer,Cost,Eval,Alpha1,Beta))
           return Cost[Maximizer]
    return Cost[Maximizer]

BestMove_track=FindBestMove(R1_Available,R2_Available,Next_Move,Previous_Move,d,Cost,VisitedList,Used_Vertices,Eval,Alpha1,Beta)
Outfile.write(BestMove_track+'\n')

toWrite=""
toWrite2=""
i=0
while i<len(finalMoves): 
    a = round(finalMoves[i])
    toWrite2 = toWrite2 + str(a)+","
    i=i+1
toWrite2=toWrite2.strip(",")
toWrite2=toWrite2.strip()
Outfile.write(toWrite2)
f.close()
Outfile.close()